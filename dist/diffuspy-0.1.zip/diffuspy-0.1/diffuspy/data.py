class Collect():
    """Collect data for the problem

    """
    def __init__(self):
        self.cndtvt = {}
        self.spcfht = {}
        self.dnsty = {}
